
public class Massimo {

	public static void main(String[] args) {

		int a, b, c;
		a = 19;
		b = 17;
		c = 51;

		if (a > b) {
			if (a > c) {
				System.out.printf("Il massimo dei numeri a = %d, b = %d e c = %d è: a = %d", a, b, c, a);
			} else {
				System.out.printf("Il massimo dei numeri a = %d, b = %d e c = %d è: c = %d", a, b, c, c);
			}
		} else {
			if (b > c) {
				System.out.printf("Il massimo dei numeri a = %d, b = %d e c = %d è: b = %d", a, b, c, b);
			} else {
				System.out.printf("Il massimo dei numeri a = %d, b = %d e c = %d è: c = %d", a, b, c, c);
			}
		}
	}

}
