
public class Crescente {

	public static void main(String[] args) {

		int a, b, c;
		a = 19;
		b = 7;
		c = 51;

		if (a > b) {
			if (a > c) {
				if (b > c) {
					System.out.println(c);
					System.out.println(b);
					System.out.println(a);				
				} else {
					System.out.println(b);
					System.out.println(c);
					System.out.println(a);								
				}
			} else {
				System.out.println(b);
				System.out.println(a);
				System.out.println(c);							
			}
		} else {
			if (b > c) {
				if (a > c) {
					System.out.println(c);
					System.out.println(a);
					System.out.println(b);				
				} else {
					System.out.println(a);
					System.out.println(c);
					System.out.println(b);				
				}
			} else {
				System.out.println(a);
				System.out.println(b);
				System.out.println(c);				
			}
		}
	}
}
