
public class Pari {

	public static void main(String[] args) {
		// Questo è un commento su una linea
		
		/*
		 * Questo è un commento
		 * su più linee
		 */
		
		
		int n = 4;

		if (n % 2 == 0){
			System.out.println("Il numero è pari");

		} else {
			System.out.println("Il numero è dispari");

		}
		

	}

}
