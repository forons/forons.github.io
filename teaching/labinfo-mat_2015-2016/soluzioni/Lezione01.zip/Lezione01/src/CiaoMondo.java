
/**
 * @author cristian
 *
 */
public class CiaoMondo {

	public static void main(String[] args) {
		
		String name = "Cristian";
		
		System.out.println("Ciao, Mondo!");
		System.out.println("Ciao, " + name + "!");

	}

}
