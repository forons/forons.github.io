
public class Intervallo {

	public static void main(String[] args) {

		// I numeri a e b definiscono un intervallo
		int a, b;
		double x;

		a = 2;
		b = 7;
		x = 5.0;

		if ((x >= a) && (x <= b)) {
			System.out.printf("Il numero %f è compreso nell'intervallo [%d, %d].", x, a, b);
		} else {
			System.out.printf("Il numero %f non è compreso nell'intervallo [%d, %d].", x, a, b);
		}

	}

}
