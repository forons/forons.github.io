
public class Divisione {

	public static void main(String[] args) {
		
		int a, b;
		a = 11;
		b = 3;

		System.out.printf("La divisione intera a/b da come risultato: %d/%d = %d\n", a, b, a/b);
		System.out.printf("Il resto della divisione è: %d\n", a % b);

	}
	
}
