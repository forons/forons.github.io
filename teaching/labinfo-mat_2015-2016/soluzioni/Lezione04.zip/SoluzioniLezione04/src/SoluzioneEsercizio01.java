import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SoluzioneEsercizio01 {

	public static void main(String[] args) throws FileNotFoundException {

		String FILENAME_IN = "esercizio01.txt";

		File file = new File(FILENAME_IN);
		Scanner scan = new Scanner(file);

		int dimensione;
		int arr[];
		int maxLocale;
		int maxGlobale;

		dimensione = scan.nextInt();
		arr = new int[dimensione];

		maxGlobale = Integer.MIN_VALUE;
		while (scan.hasNext()) {

			// Leggo l'input dal file e lo salvo nell'array
			for (int i = 0; i < dimensione; i++) {
				arr[i] = scan.nextInt();
			}

			// cerco il massimo locale nell'array
			maxLocale = Integer.MIN_VALUE;
			for (int i = 0; i < dimensione; i++) {
				if (arr[i] > maxLocale) {
					maxLocale = arr[i];
				}
			}
			if (maxGlobale < maxLocale) {
				maxGlobale = maxLocale;
			}

			// Stampo l'array e il massimo locale:
			for (int i = 0; i < dimensione - 1; i++) {
				System.out.printf("%d ", arr[i]);
			}
			System.out.printf("%d -  max locale: %d.%n", arr[dimensione - 1], maxLocale);
		}
		scan.close();

		System.out.printf("---%n");
		System.out.printf("Il massimo globale è %d.%n", maxGlobale);
	}

}
