import java.util.Scanner;

public class InizializzaArray {

	public static void main(String[] args) {

		int N;
		int[] arr;
		int count;

		Scanner input = new Scanner(System.in);

		System.out.print("Inserisci un numero intero positivo N con 0 < N <= 10: ");
		while (true) {
			if (!input.hasNextInt()) {
				System.out.printf("%n");
				System.out.printf("Il numero inserito non è un intero valido.%n");
				System.out.printf("Inserisci un numero intero positivo N con 0 < N <= 10: ");
				input.next();
			} else {
				N = input.nextInt();
				if ((N > 0) && (N <= 10)) {
					break;
				} else {
					System.out.printf("%n");
					System.out.printf("%nIl numero inserito non è un intero positivo minore o uguale a 10.%n");
					System.out.printf("Inserisci un numero intero positivo N con 0 < N <= 10: ");
				}
			}
		}

		/*
		 * La prossima istruzione serve per leggere il carattere 'newline' dato
		 * che dopo avere inserito il numero viene premuto invio.
		 * 
		 * Inserisci un numero intero positivo N: 10[invio]
		 * 
		 */
		input.nextLine();

		System.out.printf("%n");
		System.out.printf("Il numero inserito è: %d.%n", N);

		arr = new int[N];

		System.out.printf("%n");
		System.out.printf("%d numeri da inserire.%n", N);
		System.out.printf("Inserisci un numero: ");

		count = 0;
		while (true) {
			if (!input.hasNextInt()) {
				System.out.printf("%n");
				System.out.printf("Il numero inserito non è un intero valido.%n");
				input.next();
			} else {
				arr[count] = input.nextInt();
				count = count + 1;
				if (count == N) {
					break;
				}
			}
			System.out.printf("%n");
			System.out.printf("%d numeri da inserire.%n", N - count);
			System.out.printf("Inserisci un numero intero: ");
		}

		System.out.printf("%n");
		System.out.printf("%d numeri inseriti.%n", N);
		
		System.out.printf("%n");
		for (int i = 0; i < N; i++) {
			for (int j = 0; j <= i-1; j++) {
				System.out.printf("%d, ", arr[j]);
			}
			System.out.printf("%d%n", arr[i]);
		}
		input.close();
	}

}
