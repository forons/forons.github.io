import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class SoluzioneDivina {

	public static void main(String[] args) throws IOException {

		String FILENAME_IN = "divina_win.txt";
		String FILENAME_OUT = "risultati.txt";

		File file = new File(FILENAME_IN);
		Scanner scan = new Scanner(file);
		String line;

		int count_a = 0;
		int count_e = 0;
		int count_i = 0;
		int count_o = 0;
		int count_u = 0;
		int count = 0;
		char c;

		System.out.printf("File length: %d.%n%n", file.length());
		while (scan.hasNext()) {

			line = scan.nextLine();

			// Per stampare la riga letta basta aggiungere
			//
			// System.out.println(line);

			// Se si utilizza la funzione toLowerCase la stringa viene
			// trasformata in lettere minuscole quindi si contatno anche le
			// occorenze di 'A', 'E', 'I', 'O', 'U' come occorenze di
			// 'a', 'e', 'i', 'o', 'u' rispettivamente.
			//
			// line = line.toLowerCase();

			for (int m = 0; m < line.length(); m++) {
				c = line.charAt(m);
				count = count + 1;

				if (c == 'a') {
					count_a = count_a + 1;
				} else if (c == 'e') {
					count_e = count_e + 1;
				} else if (c == 'i') {
					count_i = count_i + 1;
				} else if (c == 'o') {
					count_o = count_o + 1;
				} else if (c == 'u') {
					count_u = count_u + 1;
				}
			}
		}

		// Avendo finito di leggere l'input possiamo chiudere lo scanner
		scan.close();

		System.out.printf("== Statistiche ==%n");
		System.out.printf("num. a: %d.%n", count_a);
		System.out.printf("num. e: %d.%n", count_e);
		System.out.printf("num. i: %d.%n", count_i);
		System.out.printf("num. o: %d.%n", count_o);
		System.out.printf("num. u: %d.%n", count_u);
		System.out.printf("totale vocali: %d.%n", count_a + count_e + count_i + count_o + count_u);
		System.out.printf("totale caratteri: %d.%n", count);

		// Scrivo su file i sisultati
		File output = new File(FILENAME_OUT);
		FileWriter fw = new FileWriter(output);
		BufferedWriter bw = new BufferedWriter(fw);

		bw.write(count_a + "\n");
		bw.write(count_e + "\n");
		bw.write(count_i + "\n");
		bw.write(count_o + "\n");
		bw.write(count_u + "\n");

		// Se avessimo voluto stampare anche la lettera interessata
		// all'inizio dela riga avremmo fatto:
		// bw.write("a: " + count_a + "\n");
		// bw.write("e: " + count_e + "\n");
		// bw.write("i: " + count_i + "\n");
		// bw.write("o: " + count_o + "\n");
		// bw.write("u: " + count_u + "\n");

		bw.close();
		fw.close();
	}
}
