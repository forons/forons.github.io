
public class ArrayFun {

	public static void modificaArray(int[] v) {
		
		for(int i = 0 ; i< v.length; i++){
			v[i] = v[i] * 2;
		}

		return;
	}
	
	public static void swapArray(int[] v) {
		
		int tmp;
		
		tmp = v[0];
		v[0] = v[1];
		v[1] = tmp;

		return;
	}
	

	public static void stampaArray(int[] v) {
		
		System.out.printf("--- v ---%n");

		for(int i = 0 ; i< v.length; i++){
			System.out.printf("v[%d]: %d%n", i, v[i]);
		}

		System.out.printf("---%n");

		return;
	}

	public static void main(String[] args) {

		int[] v;

		v = new int[5];

		stampaArray(v);

		v[0] = 100;
		v[1] = 101;
		v[2] = 102;
		v[3] = 103;
		v[4] = 104;

		stampaArray(v);
		
		modificaArray(v);
		
		stampaArray(v);

		swapArray(v);
		
		stampaArray(v);

		return;
	}

}
