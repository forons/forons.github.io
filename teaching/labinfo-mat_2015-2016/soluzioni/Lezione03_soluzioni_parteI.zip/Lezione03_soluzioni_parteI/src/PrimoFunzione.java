
public class PrimoFunzione {

	public static boolean isPrimo(int numero) {
		
		if (numero == 0 || numero == 1) {
			return false;			
		}

		for(int n = 2; n <= Math.sqrt(numero); n++) {			
			if(numero % n == 0) {
				return false;
			}
		}
		
		return true;
		
	}

	public static void main(String[] args) {
		
		int N_MAX = 100;
		
		for(int n = 0; n <= N_MAX; n++) {
			if (isPrimo(n)) {
				System.out.printf("%03d è un numero primo!%n", n);
			} else {
				System.out.printf("%03d NON è un numero primo!%n", n);
			}
		}
	}

}
