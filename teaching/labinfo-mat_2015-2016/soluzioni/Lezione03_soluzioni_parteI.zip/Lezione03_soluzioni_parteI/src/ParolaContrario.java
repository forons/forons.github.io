
public class ParolaContrario {

	public static void stampaParolaAlContrario(String parola) {

		for(int i = parola.length() - 1; i >= 0; i--) {
			System.out.printf("%s", parola.charAt(i));
		}	
		System.out.println("");

		return;
	}

	/*
	 * Questo è un altro modo di ottenere la soluzione usando le "funzioni
	 * predefinite" di Java.
	 */
	public static void rovesciaParolaEStampa(String parola) {
		System.out.println(new StringBuilder(parola).reverse().toString());
	}

	public static void main(String[] args) {
		
		String s1 = "gatto";
		String s2 = "anna";
		
		System.out.println("--- Primo metodo ---");
		stampaParolaAlContrario(s1);
		stampaParolaAlContrario(s2);
		System.out.println("---");
		
		System.out.println("--- Secondo metodo ---");
		rovesciaParolaEStampa(s1);
		rovesciaParolaEStampa(s2);
	}

}
