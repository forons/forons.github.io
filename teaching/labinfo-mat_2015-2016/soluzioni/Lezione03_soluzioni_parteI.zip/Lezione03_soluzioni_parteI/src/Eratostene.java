
public class Eratostene {

	public static void main(String[] args) {
		
//		int N = 100;
//		
//		int [] sieve;
//		
//		sieve = new int[N];
//		
//		for(int i=1; i < N; i++) {
//			primo = sieve[i]
//			
//		}
		

	}

}
