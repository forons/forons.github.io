
public class Primo {

	public static void main(String[] args) {
		
		int numero = 11;
		
		for(int n = 2; n <= Math.sqrt(numero); n++) {
			
			if(numero % n == 0) {
				System.out.printf("Il numero %d non è primo", numero);
				return;
			}
		}
		
		System.out.printf("Il numero %d è primo", numero);
	}
}
