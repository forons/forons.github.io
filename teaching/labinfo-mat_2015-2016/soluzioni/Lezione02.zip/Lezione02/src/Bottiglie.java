
public class Bottiglie {

	public static void main(String[] args) {
		
		System.out.printf("«");
		
		for(int n = 99; n>2; n--) {
			System.out.printf("%d bottles of beer on the wall, %d bottles of beer.%n", n, n);
			System.out.printf("Take one down, pass it around, %d bottles of beer on the wall.%n", n - 1);
		}
		
		System.out.printf("%d bottles of beer on the wall, %d bottles of beer.%n", 2, 2);
		System.out.printf("Take one down, pass it around, %d bottle of beer on the wall.%n", 1);
		System.out.printf("%d bottle of beer on the wall, %d bottle of beer.%n", 1, 1);
		System.out.printf("Take one down, pass it around, no more bottles of beer on the wall");

		System.out.printf("There are no more bottles of beer on the wall, no more bottles of beer.");
		System.out.printf("»%n");

	}

}
