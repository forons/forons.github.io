
public class CiaoDieci {

	public static void main(String[] args) {
		
		int k = 0;

		for(int i=0; i < 3; i++){
			System.out.println("Ciao, mondo!");			
		}
		for(int i=1; i <= 3; i++){
			System.out.println("Ciao, mondo!");
		}
		
		k = 0;
		while(k < 3) {
			System.out.println("Ciao, mondo!");
			k = k + 1;	// k++ è equivalente 
		}

		k = 0;
		do {
			System.out.println("Ciao, mondo!");
			k = k + 1;
		} while(k < 0);

	}

}
