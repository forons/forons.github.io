
public class TabellinaWhile {

	public static void main(String[] args) {

		int numero = 7;
		int i = 0;

		i = 0;
		
		System.out.printf("== Tabellina del %d ==%n%n", numero);
		while (i <= 10) {
			System.out.printf("%d*%d\t= %d%n", numero, i, numero * i);
			i = i + 1;
		}

	}

}
