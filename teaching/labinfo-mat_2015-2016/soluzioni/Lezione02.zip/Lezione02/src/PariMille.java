
public class PariMille {

	public static void main(String[] args) {

		int n;

		for (n = 1; n <= 1000; n++) {
			if(n % 2 == 0){
				System.out.printf("Il numero %d è pari.%n", n);
			}
		}

	}

}
