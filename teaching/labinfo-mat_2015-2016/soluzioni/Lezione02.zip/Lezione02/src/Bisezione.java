
public class Bisezione {

	/*
	 * 
	 * È possibile anche definire una funzione f(x) per i dettagli si veda la
	 * lezione 3
	 * 
	 * public static double f(double x){ return x*x*x - x - 2; }
	 *
	 */

	public static void main(String[] args) {

		double a = 0;
		double b = 0;
		double c = 0;

		double EPS_X = 0.0001;
		double EPS_Y = 0.0001;

		int n = 0;
		int NMAX_PASSI = 10000;
		double RESULT = 1.521379706804567;

		a = 1.0;
		b = 2.0;
		// Controllare se i valori f(a) e f(c) sono discordi equivale a
		// controllare se il
		// loro prodotto è positivo.
		if ((a * a * a - a - 2) * (b * b * b - b - 2) > 0) {
			System.out.println("f(a), ovvero f(%d), e f(b), ovvero f(%d), sono concordi.%n");
			System.out
					.println("Per applicare il metodo della bisezione serve che negli estremi dell'intervallo [a, b]");
			System.out.println("la funzione f assuma valori discordi.%n");
			return;
		}

		while (n < NMAX_PASSI) {
			c = (a + b) / 2.0;

			if (Math.abs(c * c * c - c - 2) < EPS_Y || Math.abs((b - a) / 2.) < EPS_X) {
				System.out.printf("Il valore approssimato dello zero della funzione è: %.10f.%n", c);
				System.out.printf("f(c): f(%f) = %f.%n", c, (c * c * c - c - 2));
				System.out.printf("---%n");
				System.out.printf("Risultato corretto (calcolato con Math.sqrt): r = %.10f%n", RESULT);
				System.out.printf("|c - r| = %.10f%n", Math.abs(RESULT - c));
				return;
			}
			n = n + 1;

			// Il controllo presente nello pseudocodice:
			//
			// if sign(f (c)) = sign(f (a))
			//
			// ovvero controllare se i valori f(a) e f(c) sono concordi,
			// ovvero se il loro prodotto è positivo.
			if ((a * a * a - a - 2) * (c * c * c - c - 2) > 0) {
				a = c;
			} else {
				b = c;
			}
		}

		System.out.printf("Non sono riuscito a trovare una radice con la precisione desiderata ");
		System.out.printf("entro %d passi", NMAX_PASSI);
		return;
	}

}
