
public class BisezioneFunzione {

	public static double f(double x) {
		return x * x * x - x - 2;
	}

	public static void main(String[] args) {

		double a = 0;
		double b = 0;
		double c = 0;

		double EPS_X = 0.0001;
		double EPS_Y = 0.0001;

		int n = 0;
		int NMAX_PASSI = 10000;
		double RESULT = 1.521379706804567;

		a = 1.0;
		b = 2.0;
		// Controllare se i valori f(a) e f(c) sono discordi equivale a controllare se il
		// loro prodotto è positivo.
		if (f(a) * f(b) > 0) {

			System.out.printf("f(a), ovvero f(%f), e f(b), ovvero f(%f), sono concordi.%n",a, b);
			System.out.printf("Per applicare il metodo della bisezione serve che negli estremi ");
			System.out.printf("dell'intervallo [a, b] la funzione f assuma valori discordi.%n");
			return;
		}

		while (n < NMAX_PASSI) {
			c = (a + b)/2.0;

			if (Math.abs(f(c)) < EPS_Y || Math.abs((b - a)/2.) < EPS_X ) {
				System.out.printf("Il valore approssimato dello zero della funzione è: %.10f.%n", c);
				System.out.printf("f(c): f(%f) = %f.%n", c, f(c));
				System.out.printf("---%n");
				System.out.printf("Risultato corretto (calcolato con Math.sqrt): r = %.10f%n", RESULT);
				System.out.printf("|c - r| = %.10f%n", Math.abs( RESULT - c ));
				return;
			}
			n = n + 1;

			// Il controllo presente nello pseudocodice:
			//
			//     if sign(f (c)) = sign(f (a))
			//
			// ovvero controllare se i valori f(a) e f(c) sono concordi,
			// ovvero se il loro prodotto è positivo.
			if (f(a) * f(c) > 0) {
				a = c;
			} else {
				b = c;
			}
		}
		
		System.out.printf("Non sono riuscito a trovare una radice con la precisione desiderata ");
		System.out.printf("entro %d passi", NMAX_PASSI);
		return;
	}

}
