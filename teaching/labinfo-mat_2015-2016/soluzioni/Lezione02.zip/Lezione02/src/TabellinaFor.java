
public class TabellinaFor {

	public static void main(String[] args) {

		int numero = 7;

		System.out.printf("== Tabellina del %d ==%n%n", numero);
		for(int i = 0; i <= 10; i++) {
			System.out.printf("%d*%d\t= %d%n", numero, i, numero * i);
		}

	}

}
