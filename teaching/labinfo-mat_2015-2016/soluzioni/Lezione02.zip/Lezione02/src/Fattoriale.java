
public class Fattoriale {

	public static void main(String[] args) {
		int n = 5;
		int fatt = 0;

		fatt = 1;
		for (int i = 1; i <= n; i++) {
			fatt *= i;
		}

		System.out.printf("Il fattoriale di %d è: %d! = %d%n", n, n, fatt);
	}
}
