
public class Netwon {

	public static void main(String[] args) {
		
		double Z = 20;
		double X0 = 0.25;
		double EPS = 0.001;
		int NMAX = 1000;

		double err = 0.;
		double x_n = 0.;
		double r_n = 0.;
		double x_prec = 0.;
		

		// Calcolo la formula ricorsiva:
		// x_{n+1} = 0.5*x_n*(3 − z*x_n^{2})

		x_prec = X0;
		for (int n=0; n < NMAX; n++) {

			x_n = 0.5 * x_prec* (3.0 - Z*x_prec*x_prec);
			
			// x_n converge a 1/sqrt(z) quindi calcolo il reciproco, r_n
			// e confronto r_n^2 con Z
			r_n = 1.0/x_n;
			err = Math.abs(r_n*r_n - Z);
			
			System.out.printf("n: %d - x_n: %f, r_n: %f, err: %f.%n", n, x_n, r_n, err);
			if (err < EPS) {
				System.out.printf("Sono riuscito a calcolare sqrt(%f) con la precisione desiderata.%n", Z);
				System.out.printf("x_%d: %f", n, r_n);
				return;
			}

			x_prec = x_n;
		}
		
		System.out.printf("NMAX raggiunto.%n");
		System.out.printf("Non sono riuscito a calcolare sqrt(%f) con la precisione desiderata.%n", Z);
		System.out.printf("x_%d: %f", NMAX, x_n);
		return;
	}
}
