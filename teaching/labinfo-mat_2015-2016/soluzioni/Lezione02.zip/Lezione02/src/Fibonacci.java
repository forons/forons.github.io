
public class Fibonacci {

	public static void main(String[] args) {

		int x = 0;
		int x1 = 1;
		int x0 = 1;
		int xm = 0;
		int xmm = 0;
		int i = 0;
		int LIMITE = 10000;

		System.out.printf("== Serie di Fibonacci ==%n");
		System.out.printf("x_%d: %d%n", 0, x0);
		System.out.printf("x_%d: %d%n", 1, x1);

		i = 2;
		xmm = x0;
		xm = x1;
		while ((xm + xmm) < LIMITE) {

			x = xm + xmm;

			System.out.printf("x_%d: %d%n", i, x);

			xmm = xm;
			xm = x;

			i = i + 1;

		}
	}

}
