
public class Fattoriale20 {

	public static void main(String[] args) {

		int N = 20;
		int n = 0;
		int fatt = 0;

		/*
		 * Questo programma stampa il fattoriale di n per tutti gli
		 * n da 0 a 20 (N).
		 * Cosa succede
		 * Il fattoriale di 0 è: 0! = 1
		 * Il fattoriale di 1 è: 1! = 1
		 * Il fattoriale di 2 è: 2! = 2
		 * Il fattoriale di 3 è: 3! = 6
		 * Il fattoriale di 4 è: 4! = 24
		 * Il fattoriale di 5 è: 5! = 120
		 * Il fattoriale di 6 è: 6! = 720
		 * Il fattoriale di 7 è: 7! = 5040
		 * Il fattoriale di 8 è: 8! = 40320
		 * Il fattoriale di 9 è: 9! = 362880
		 * Il fattoriale di 10 è: 10! = 3628800
		 * Il fattoriale di 11 è: 11! = 39916800
		 * Il fattoriale di 12 è: 12! = 479001600
		 * Il fattoriale di 13 è: 13! = 6227020800
		 * Il fattoriale di 14 è: 14! = 87178291200
		 * Il fattoriale di 15 è: 15! = 1307674368000
		 * Il fattoriale di 16 è: 16! = 20922789888000
		 * Il fattoriale di 17 è: 17! = 355687428096000
		 * Il fattoriale di 18 è: 18! = 6402373705728000
		 * Il fattoriale di 19 è: 19! = 121645100408832000
		 * Il fattoriale di 20 è: 20! = 2432902008176640000
		 * 
		 * I risultati di questo programma sono errati da n > 12 in poi.
		 * Come mai?
		 * 
		 *  (Per ottenere i risultati corretti sostituire il tipo di fatt da
		 *  int a long, ovvero
		 *
		 * long fatt = 0;
		 */
		while (n <= N) {
			fatt = 1;
			for (int i = 1; i <= n; i++) {
				fatt *= i;
			}

			System.out.printf("Il fattoriale di %d è: %d! = %d%n", n, n, fatt);
			n = n + 1;
		}
	}

}
