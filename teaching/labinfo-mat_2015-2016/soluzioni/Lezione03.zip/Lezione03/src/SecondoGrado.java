
public class SecondoGrado {

	public static double discriminante(double a, double b, double c) {
		// b^2 - 4*a*c
		return (b*b - 4*a*c);
	}

	public static void solve(double a, double b, double c) {
		
		double Delta;

		if(a == 0.0) {
			// a = 0 -> b*x + c = 0
			System.out.printf("Il coefficiente del temine x^2 è zero.%n");
			if(b == 0.0) {
				// a = 0, b = 0 -> c = 0
				System.out.printf("Il coefficiente del termine x è zero.%n");
				
				if (c == 0) {
					// a = 0, b = 0, c = 0 -> 0 = 0
					System.out.printf("Identità 0 = 0. Infinite soluzioni.%n");
				} else {
					// a = 0, b = 0, c != 0 -> contraddizione
					System.out.printf("Contraddizione %f = 0. Nessuna soluzione reale.%n", c);
				}
			} else {
				// a = 0, b != 0 -> x = c/b
				System.out.printf("Equazione di primo grado %f*x + %f = 0  => x = %f.%n", b, c, c/b);
			}
		} else {
			// a != 0 -> a*x^2 + b*x + c = 0
			if(b == 0.0) {
				// a != 0, b = 0 -> a*x^2 + c = 0
				System.out.printf("Il coefficiente del termine x è zero.%n");
				
				if (a * c > 0.0) {
					// b = 0 -> x^2 = - c/a (< 0)
					System.out.printf("L'equazione %f*x^2 + %f = 0 non ha nessuna soluzione reale.%n", a, c);
				} else {
					// b = 0 -> x^2 = - c/a (> 0)
					System.out.printf("L'equazione %f*x^2 + %f = 0 ha due soluzioni reali coincidenti.", a, c);
					System.out.printf("x_1 = -%f, x_2 = %f.%n", Math.sqrt(-c/a), -Math.sqrt(-c/a));
				}
			} else {
				// a != 0, b != 0 -> x_{1,2} = (-b +/- sqrt(delta))/(2*a)
				System.out.printf("Equazione di secondo grado %f*x^2 + %f*x + %f = 0.%n", a, b, c);
				
				Delta = discriminante(a, b, c);

				if(Delta < 0.0) {
					// Delta < 0
					System.out.printf("Discriminante negativo: Delta = %f.%n", Delta);
					System.out.printf("Nessuna soluzione reale%n");
				} else if(Delta == 0.0) {
					// Delta = 0
					System.out.printf("Discriminante nullo.%n");
					System.out.printf("Due soluzioni reale coincidenti: x_{1, 2} = %f.%n", -b/(2*a));
				} else {
					// Delta > 0
					System.out.printf("Discriminante positivo.%n");
					System.out.printf("Due soluzioni reali distinte.%n");
					System.out.printf("x_1 = %f.%n", (-b + Math.sqrt(Delta))/(2*a));
					System.out.printf("x_2 = %f.%n", (-b - Math.sqrt(Delta))/(2*a));
				}
			}
		}

		return;
	}

	public static void main(String[] args) {
		
		double a = 4.0;
		double b = 0.0;
		double c = -1.0;

		solve(a, b, c);
	}
}
