import java.util.Arrays;

public class InsertionSort {

	/*
	 * Creo una procedura per la stampa dell'array
	 */
	public static void stampaVettore(int[] v) {
		for (int i = 0; i < v.length; i++) {
			System.out.printf("%d: %d.%n", i, v[i]);
		}
	}

	public static int[] insertionSort(int[] A) {

		int[] v;
		int min;
		int min_idx;
		int tmp;

		v = Arrays.copyOf(A, A.length);

		for (int i = 0; i < v.length; i++) {

			min = Integer.MAX_VALUE;
			min_idx = -1;

			for (int j = i; j < v.length; j++) {
				if (v[j] < min) {
					min = v[j];
					min_idx = j;
				}
			}

			tmp = v[i];
			v[i] = v[min_idx];
			v[min_idx] = tmp;
		}

		return v;
	}

	public static void main(String[] args) {

		int[] arr = { 10, 4, 2, 1, 9, 8, 6, 5, 3, 7 };
		int[] sorted_arr;

		stampaVettore(arr);

		sorted_arr = insertionSort(arr);

		System.out.printf("---%n");
		stampaVettore(sorted_arr);
	}

}
