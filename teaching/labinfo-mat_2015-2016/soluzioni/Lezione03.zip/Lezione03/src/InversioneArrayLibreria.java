/*
 * 
 * Questa versione della soluzione utilizza
 * una libreria esterna di Java chiamata
 * Apache Commons Lang
 * https://commons.apache.org/proper/commons-lang/
 * che contiene una funzione reverse della forma
 * 
 * ArrayUtils.reverse(int[] array);
 * 
 * che "rovescia" un array di interi.
 * 
 * per potere utilizzare librerie esterne uno dei
 * metodi è importare un file JAR contenente la libreria
 * è possibile farlo andando nelle proprietà del progetto
 * (menu Progetto > Proprietà) e selezionando dalla finestra
 * che comparirà la voce "Java Build Path". A questo punto
 * troverete una scheda chiamata "Librerie" nella quale
 * potrete aggiungere le librerie esterne che vi servono.
 * 
 */

import org.apache.commons.lang3.ArrayUtils;

public class InversioneArrayLibreria {

	/*
	 * Creo una procedura per la stampa dell'array
	 */
	public static void stampaVettore(int[] v) {
		for(int i = 0; i < v.length; i++) {
			System.out.printf("%d: %d.%n", i, v[i]);
		}		
	}

	public static void main(String[] args) {
		
		int NDIM = 10;
		int[] arr = new int[NDIM];
		
		for(int i = 0; i < arr.length; i++) {
			arr[i] = i + 1;
		}
		
		stampaVettore(arr);
				
		System.out.printf("---%n");
		
		ArrayUtils.reverse(arr);
		
		stampaVettore(arr);
	}

}
