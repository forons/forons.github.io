import java.util.Arrays;

public class MatriceTrasposta {

	public static void stampaMatrice(int[][] M) {

		// Assumo che la matrice sia quadrata
		int dim = M.length;

		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim - 1; j++) {
				System.out.printf("%2d, ", M[i][j]);
			}
			System.out.printf("%d%n", M[i][dim - 1]);
		}
	}

	public static int[][] trasponi(int[][] M) {

		// Assumo che la matrice sia quadrata, quindi
		// la dimensione lungo le righe è la stessa
		// lungo le colonne
		int dim = M.length;
		int tmp;
		int[][] mat;

		// Creo una copia dell'array M chiamata mat
		// per farlo alloco prima un vettore di
		// lunghezza pari al numero di righe e poi
		// copio il contenuto dell'array originale
		// usando il metodo copyOf della libreria di
		// sistema Arrays.
		mat = new int[dim][];
		for(int i = 0; i < dim; i++) {
			mat[i] = Arrays.copyOf(M[i], dim);
		}
		
		for(int i = 0; i < dim; i++) {
			for(int j = i; j < dim; j++) {
				tmp = mat[i][j];
				mat[i][j] = mat[j][i];
				mat[j][i] = tmp;
			}
		}
		
		return mat;
	}

	public static int generaNumeroCasuale(int a, int b) {

		double num;

		/*
		 * Math.random() produce un numero pseudocasuale (double) compreso in
		 * [0, 1) (0 compreso, 1 escluso)
		 */
		num = Math.floor(Math.random() * (b + 1 - a) + a);

		/*
		 * La sintassi: (int) num si dice "cast" della variabile.
		 * 
		 * Si tratta di una conversione della variabile num da double a int.
		 */
		return (int) num;

	}

	public static void main(String[] args) {

		int DIM = 5;
		int NMIN = 0;
		int NMAX = 99;

		int[][] M = new int[DIM][DIM];
		int[][] Mtrasp;

		/* 
		 * Un esempi per iniziare una matrice è fare
		 * una dichiarazione usando i literals:
		 * 
		 * 	int[][] M = { { 1, 9, 3, 7, 2 },
		 *	     		  { 0, 1, 2, 3, 4 },
		 *		    	  { 3, 2, 4, 6, 8 },
		 *			      { 0, 3, 6, 9, 12 },
		 *			      { 7, 4, 8, 12, 16 }
		 *			    };
		 *
		 */

		stampaMatrice(M);
		System.out.printf("---%n");

		for(int i = 0; i < DIM; i++) {
			for(int j = 0; j < DIM; j++) {
				M[i][j] = generaNumeroCasuale(NMIN, NMAX);
			}
		}

		System.out.printf("--- Matrice M ---%n");
		stampaMatrice(M);
		System.out.printf("---%n");

		System.out.printf("--- Matrice trasposta M^T ---%n");
		Mtrasp = trasponi(M);
		stampaMatrice(Mtrasp);

		System.out.printf("--- Matrice M ---%n");
		stampaMatrice(M);
		System.out.printf("---%n");

	}
}
