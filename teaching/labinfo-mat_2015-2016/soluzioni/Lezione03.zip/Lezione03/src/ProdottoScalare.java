
public class ProdottoScalare {

	public static double prodottoScalare(double[] v, double[] w) {
		double s = 0.0;

		for (int i = 0; i < v.length; i++) {
			s = s + v[i] * w[i];
		}

		return s;
	}

	public static void main(String[] args) {

		double[] a = { 1.0, 2.0, 3.0 };
		double[] b = { 4.0, 5.0, 6.0 };
		double[] x = { 1.0, 1.0 };
		double[] y = { 1.0, -1.0 };
		double res;
		
		res = prodottoScalare(a, b);
		System.out.printf("Il prodotto scalare dei vettori a e b è: %f.%n", res);

		res = prodottoScalare(x, y);
		System.out.printf("Il prodotto scalare dei vettori x e y è: %f.%n", res);
	}

}
