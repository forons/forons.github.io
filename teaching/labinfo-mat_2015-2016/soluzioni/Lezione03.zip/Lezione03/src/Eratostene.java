
public class Eratostene {

	public static void main(String[] args) {

		int N = 100;

		boolean[] sieve;

		int n_primi = 0;
		int ind_primi = 0;
		int[] primi;

		// per comodità considero l'indice i del vettore sieve
		// essere il numero da verificare.
		// Quindi riempi il vettore da 0 fino a N, mi servono
		// N + 1 elementi
		sieve = new boolean[N + 1];

		// 0 non è un numero primo
		sieve[0] = false;

		// 1 non è un numero primo (per definizione)
		sieve[1] = false;

		// inizializzo il crivello: tutti i numeri che incontro
		// (ovvero che non vengono eliminati in qualche punto 
		// del processo) sono primi, quindi inizializzo tutti
		// i valori a true.
		for (int i = 2; i <= N; i++) {
			sieve[i] = true;
		}

		// n_primi è una variabile che utilizzo per conteggiare
		// il numero di primi da 1 a N.
		n_primi = 0;
		for (int i = 2; i <= N; i++) {
			if (sieve[i]) {
				// sieve[i] == true
				n_primi = n_primi + 1;

				// se il numero è ancora in sieve allora è primo, devo eliminare
				// i suoi multipli.
				// Creo un ciclo con j = 2, 3, ... e continuo finché i multipli
				// (i*j) non sono più grandi di N, quindi !(i*j > N) => i*j <= N
				for (int j = 2; i * j <= N; j++) {
					sieve[i * j] = false;
				}
			} else {
				// sieve[i] == false
				// non devo fare nulla e posso continuare
				// per chiarezza uso la keyword continue
				continue;
			}
		}

		// So che da 1 a N ci sono n_primi primi, quindi alloco un array della
		// dimensione opportuna
		primi = new int[n_primi];

		// utilizzo ind_primi come indice per riempire il vettore
		ind_primi = 0;
		for (int i = 0; i < N; i++) {
			if (sieve[i]) {
				primi[ind_primi] = i;
				ind_primi = ind_primi + 1;
			}
		}
		
		// Stampo i risultati a schermo
		System.out.printf("I numeri primi da 1 a %d sono i seguenti:%n", N);
		for (int i = 0; i < n_primi; i++) {
			System.out.printf("%d%n", primi[i]);
		}
	}
}
