
public class FattorialeRicorsivo {

	public static int fattoriale(int n) {
		
		if (n == 0) {
			return 1;
		}
		
		return n * fattoriale(n - 1);
	}

	public static void main(String[] args) {
		
		int numero = 10;
		int risultato = 0;
		
		risultato = fattoriale(numero);
		System.out.printf("Il fattoriale di %d è: %d", numero, risultato);

	}

}
