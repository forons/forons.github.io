
public class SommaInteriCiclo {

	public static int sommaInteriRicorsiva(int N) {
		
		if (N == 1) {
			return 1;
		} else {
			return N + sommaInteriRicorsiva(N - 1);
		}
		
	}

	public static void main(String[] args) {

		int N_MAX = 100;
		int s_ricors = 0;

		for(int i = 1; i <= N_MAX; i++) {
			
			s_ricors = sommaInteriRicorsiva(i);
			System.out.printf("La somma degli interi da 1 a %d è: sommaInteriRicorsiva(%d) = %d.%n", i, i, s_ricors);
		}

	}

}
