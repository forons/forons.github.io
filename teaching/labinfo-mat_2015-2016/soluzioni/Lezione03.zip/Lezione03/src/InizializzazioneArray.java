
public class InizializzazioneArray {

	/*
	 * Creo una procedura per la stampa dell'array
	 */
	public static void stampaVettore(int[] v) {
		for(int i = 0; i < v.length; i++) {
			System.out.printf("%d: %d.%n", i, v[i]);
		}		
	}

	public static void main(String[] args) {
		
		int NDIM = 10;
		int[] arr = new int[NDIM];

		stampaVettore(arr);
		
		for(int i = 0; i < arr.length; i++) {
			arr[i] = 5;
		}
		System.out.printf("---%n");
		
		stampaVettore(arr);
	}

}
