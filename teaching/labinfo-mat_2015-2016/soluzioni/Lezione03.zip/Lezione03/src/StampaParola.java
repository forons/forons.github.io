
public class StampaParola {
	/*
	 * Notate che tutte le funzioni hanno nomi 
	 * in cui l'iniziale delle parole è maiuscola.
	 * Questa notazione si chiama camelCase.
	 * 
	 * https://it.wikipedia.org/wiki/Notazione_a_cammello
	 * 
	 */
	
	public static void stampaParolaInVerticale(String parola) {
		parola = parola.toUpperCase();

		for(int i = 0; i < parola.length(); i++) {
			System.out.println(parola.charAt(i));
		}
		
	}
	public static void main(String[] args) {
		
		String parola = "Ciao";
		
		System.out.printf("La parola da stampare è: %s.%n", parola);
		stampaParolaInVerticale(parola);
		System.out.printf("La parola stampata è: %s.%n", parola);

	}
}
