
public class InsertionSortAlternativo {

	/*
	 * Creo una procedura per la stampa dell'array
	 */
	public static void stampaVettore(int[] v) {
		for (int i = 0; i < v.length; i++) {
			System.out.printf("%d: %d.%n", i, v[i]);
		}
	}

	/*
	 * Pseudocodice per insertion sort
	 * fonte: https://it.wikipedia.org/wiki/Insertion_sort
	 * 
	 * function insertionSort(array A)
	 * for i ← 1 to length[A] do
	 *     value ← A[i]
	 *     j ← i-1 
	 *     
	 *     while j >= 0 and A[j] > value do 
	 *         A[j + 1] ← A[j]
	 *         j ← j-1
	 *     A[j+1] ← value
	 */
	public static void insertionSort(int[] A) {

		int value;
		int j;

		for (int i = 1; i < A.length; i++) {
			
			value = A[i];
			j = i - 1;

			while ((j >= 0) && (A[j] > value)) {
				A[j + 1] = A[j];
				j = j - 1;
			}
			
			A[j + 1] = value;
		}

		return;
	}

	/*
	 * Questa funzione genera un numero casuale intero tra a e b (estremi
	 * inclusi)
	 */
	public static int generaNumeroCasuale(int a, int b) {

		double num;

		/*
		 * Math.random() produce un numero pseudocasuale (double) compreso in
		 * [0, 1) (0 compreso, 1 escluso)
		 */
		num = Math.floor(Math.random() * (b + 1 - a) + a);

		/*
		 * La sintassi: (int) num si dice "cast" della variabile.
		 * 
		 * Si tratta di una conversione della variabile num da double a int.
		 */
		return (int) num;

	}

	public static void main(String[] args) {

		int DIM = 10;
		int N_MIN = 0;
		int N_MAX = 100;

		int[] arr = new int[DIM];

		for (int i = 0; i < arr.length; i++) {
			arr[i] = generaNumeroCasuale(N_MIN, N_MAX);
		}

		stampaVettore(arr);

		insertionSort(arr);

		System.out.printf("---%n");
		stampaVettore(arr);
	}

}
