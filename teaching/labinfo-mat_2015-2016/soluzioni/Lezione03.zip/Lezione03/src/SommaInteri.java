
public class SommaInteri {

	// funzione che calcola la somma degli interi da 1 a N 
	public static int sommaInteri(int N) {
		return (N * (N + 1))/2;
		
	}

	public static double sommaInteriCiclo(int N) {
		
		int s = 0;
		
		for(int n = 1; n <= N; n++) {
			s = s + n;
		}
		
		return s;
	}

	public static void main(String[] args) {
		
		int N_MAX = 100;
		int s_interi = 0;
		int s_ciclo = 0;

		for(int i = 1; i <= N_MAX; i++) {
			
			s_interi = sommaInteri(i);
			s_ciclo = sommaInteri(i);
			System.out.printf("La somma degli interi da 1 a %d è: sommaInteri(%d) = %d, sommaInteriCiclo(%d) = %d.%n", i, i, s_interi, i, s_ciclo);
		}

	}

}
