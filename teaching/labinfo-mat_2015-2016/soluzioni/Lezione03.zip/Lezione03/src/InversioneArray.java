
public class InversioneArray {

	/*
	 * Creo una procedura per la stampa dell'array
	 */
	public static void stampaVettore(int[] v) {
		for(int i = 0; i < v.length; i++) {
			System.out.printf("%d: %d.%n", i, v[i]);
		}		
	}

	/*
	 * La funzione invertiVettore scambia la posizione
	 * degli elementi dell'array in posizione simmetriche
	 * rispetto all'elemento mediano del vettore.
	 * 
	 * Quindi in un vettore lungo 10 (indici da 0 a 9)
	 * avvengono i seguenti scambi:
	 * 
	 * indici
	 * 0  1  2  3  4  5  6  7  8  9
	 * 11 12 13 14 15 16 17 18 19 20
	 * valori
	 * 
	 * scambi:
	 * 0 <-> 9
	 * 1 <-> 8
	 * 2 <-> 7
	 * 3 <-> 6
	 * 4 <-> 5
	 * 
	 * Nel caso in cui la lunghezza del vettore sia dispari
	 * l'elemento mediano non viene scambiato.
	 * 
	 * indici
	 * 0  1  2  3  4  5  6  7  8  9  10
	 * 11 12 13 14 15 16 17 18 19 20 21
	 * valori
	 * 
	 * scambi:
	 * 0 <-> 10
	 * 1 <-> 9
	 * 2 <-> 8
	 * 3 <-> 7
	 * 4 <-> 6
	 * 
	 */
	public static void invertiVettore(int[] v) {
		
		int tmp;
		int ind = 0;

		for(int i = 0; i < v.length/2; i++) {
			ind = v.length - i - 1;
			tmp = v[ind];
			
			v[ind] = v[i];
			v[i] = tmp;
		}
	}

	public static void main(String[] args) {
		
		int NDIM = 10;
		int[] arr = new int[NDIM];
		
		for(int i = 0; i < arr.length; i++) {
			arr[i] = i + 1;
		}
		
		stampaVettore(arr);
		
		System.out.printf("---%n");
				
		invertiVettore(arr);

		stampaVettore(arr);
	}

}
