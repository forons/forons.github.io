import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GestioneEccezione {

	public static void main(String[] args) {

		int n;
		Scanner input;
		
		File file = new File("esempio.txt");
		try {
			input = new Scanner(file);
		} catch (FileNotFoundException e) {
			System.err.printf("Errore! File non trovato!%n");
			return;
		}

		n = input.nextInt();
		System.out.printf("Il valore letto è %d.%n", n);
		input.close();
	}

}
