
public class Debugging {

	public static boolean isPrime(int n) {
		
		if (n == 0 || n == 1) {
			return false;
		}

		for(int j = 2; j <= Math.sqrt(n); j++) {
			if (n % j == 0) {
				return false;
			}
		}

		return true;
	}

	public static void main(String[] args) {

		int NMAX = 10;
		int DIM = 6;

		int even[] = new int[DIM];
		int idx = 0;

		int nprimes = 0;

		idx = 0;
		for (int i = 0; i <= NMAX; i++) {

			if (i % 2 == 0) {
				System.out.printf("il numero %d è pari.%n", i);
				even[idx] = i;
				idx = idx + 1;
			} else {
				System.out.printf("il numero %d è dispari.%n", i);
			}
			
			if (isPrime(i)) {
				nprimes = nprimes + 1; 
			}

		}

	}

}
