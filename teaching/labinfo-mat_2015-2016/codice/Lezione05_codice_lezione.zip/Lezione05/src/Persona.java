public class Persona {

	private String nome;
	private String luogoNascita;
	private int eta;

	public Persona(String nome, String luogo, int eta) {
		this.setNome(nome);
		this.setLuogoNascita(luogo);
		this.setEta(eta);
	}

	public Persona() {
		this.setNome("Anonimo");
		this.setLuogoNascita("Sconosciuto");
		this.setEta(-1);
	}

	public int getEta() {
		return eta;
	}

	public void setEta(int eta) {
		this.eta = eta;
	}

	public String getLuogoNascita() {
		return luogoNascita;
	}

	public void setLuogoNascita(String luogoNascita) {
		this.luogoNascita = luogoNascita;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String toString() {
		return nome + " (" + luogoNascita + "), " + eta;
	}
}
