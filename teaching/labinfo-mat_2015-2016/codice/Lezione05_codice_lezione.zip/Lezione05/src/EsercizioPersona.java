
public class EsercizioPersona {
	
	public static void main(String[] args) {
		
		String nome1 = "Alice Rossi";
		String luogo1 = "Rossi";
		int eta = 19;

		Persona pippo = new Persona("Alice Rossi", "Milano", 99);

		System.out.println(pippo);
	}

}
