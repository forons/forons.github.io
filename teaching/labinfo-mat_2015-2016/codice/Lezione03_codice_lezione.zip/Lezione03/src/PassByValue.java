public class PassByValue {
	
	/*
	 * Una procedura o una funzione non possono
	 * modificare il valore di una variabile.
	 * 
	 * Le variabili vengono passate per valore.
	 */
	
	// La variabile a indicata all'interno di cambiaVariabile è
	// diversa da quella nel main. Le due variabili vivono in
	// due scope diversi,
	public static void cambiaVariabile(int a) {
		
		// Dentro la procedura, all'inzio a vale: 5.
		System.out.printf("Dentro la procedura, all'inzio a vale: %d.%n", a);
		
		a = a + 10;

		// Dentro la procedura, alla fine a vale: 15.
		System.out.printf("Dentro la procedura, alla fine a vale: %d.%n", a);
		
		return;
	}

	public static void main(String[] args) {
		
		int a = 5;
		
		// Stampa a schermo: la variabile a vale: 5.
		System.out.printf("la variabile a vale: %d.%n", a);
		
		cambiaVariabile(a);
		
		// Stampa a schermo: la variabile a vale: 5.
		System.out.printf("la variabile a vale: %d.%n", a);
	}
}
