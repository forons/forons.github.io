
public class EsempioFunzione {

	public static int somma(int x, int y) {
		
		// ris è una variabile locale che vive solo
		// dentro la funzione somma.
		int ris;
		ris = x + y;
		
		// avrei potuto anche scrivere return (x + y);
		return ris;
	}

	// Questa è una procedura
	public static void stampaSommaNumeri(int x, int y) {
		
		System.out.printf("Calcolo la somma di due numeri.%n");
		System.out.printf("x: %d%n", x);
		System.out.printf("y: %d%n", y);
		System.out.printf("somma: %d%n", x + y);

		// nelle procedure si può scrivere un return; vuoto per indicare
		// il punto di uscita della, ma si può anche omettere. 
		return;
	}


	public static void main(String[] args) {
		
		int a = 5;
		int b = 7;
		int risultato = 0;

		// il valore restitutito da somma è un intero che viene assegnato alla
		// variabile risultato
		risultato = somma(a, b);
		System.out.printf("Il risultato della somma di %d e %d è %d%n", a, b, risultato);

		// le procedure non ritornano alcun valore
		stampaSommaNumeri(a, b);

	}

}
