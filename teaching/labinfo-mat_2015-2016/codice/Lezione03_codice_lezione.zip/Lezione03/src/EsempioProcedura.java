
public class EsempioProcedura {

	public static void stampaParolaInVerticale(String parola) {
		
		String tmp;
		
		// Trasformo la parola tutta in MAIUSCOLO e la assegno a
		// tmp
		tmp = parola.toUpperCase();
		
		for(int i = 0; i < parola.length(); i++) {
			System.out.printf("%s%n", tmp.charAt(i));
		}
		
	}

	public static void main(String[] args) {
		
		String parola = "Ciao";
		
		stampaParolaInVerticale(parola);

	}
}
