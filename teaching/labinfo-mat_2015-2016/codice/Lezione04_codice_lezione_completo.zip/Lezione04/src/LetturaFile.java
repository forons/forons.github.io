import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LetturaFile {

	public static void main(String[] args) {
		
		File file = new File("esempio.txt");
		Scanner scan;
		try {
			scan = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
