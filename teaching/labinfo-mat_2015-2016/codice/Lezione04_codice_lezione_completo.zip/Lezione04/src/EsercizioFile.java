import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class EsercizioFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		int num;
		File file = new File("esercizio01.txt");
		Scanner input = new Scanner(file);

		num = input.nextInt();

		while (!input.hasNextInt()) {
			input.next();
		}
	}

}
