import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EsempioScrittura {

	public static void main(String[] args) throws IOException {
		
		String testo = "NuovoEsempio";
		
		File file = new File("esempioScrittura.txt");
		FileWriter fw = new FileWriter(file);
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write(testo);
		bw.flush();
		bw.close();


	}

}
