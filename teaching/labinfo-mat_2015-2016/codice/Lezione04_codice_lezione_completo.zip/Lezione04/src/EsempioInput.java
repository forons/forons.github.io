import java.util.Scanner;

public class EsempioInput {

	public static void main(String[] args) {
		
		int numero;
		Scanner input = new Scanner(System.in);

		System.out.printf("Inserisci un numero intero: ");
		numero = input.nextInt();
		
		System.out.printf("Il numero inserito è: %d.%n", numero);
	}

}
