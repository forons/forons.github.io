import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class EsempioLetturaFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		int n;
		
		File file = new File("esempio.txt");
		Scanner input = new Scanner(file);

		n = input.nextInt();
		input.close();
		
		System.out.printf("Il numero letto da file è: %d.%n", n);
	}

}
