import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GestioneEccezione {

	public static void main(String[] args) {
		
		int n;
		
		File file = new File("esempio.txt");
		try {
			Scanner input = new Scanner(file);
			n = input.nextInt();
			System.out.printf("Il valore letto è %d.%n", n);
		} catch (FileNotFoundException e) {
			System.err.printf("Errore! File non trovato!%n");
		}		

	}

}
