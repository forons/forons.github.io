import java.util.Scanner;

public class EsempioInserimentoNumeri {

	public static void main(String[] args) {
		
		int numeroInt;
		double numeroDouble;
		
		Scanner input = new Scanner(System.in);
		
		System.out.printf("Insererisci un numero: ");
		if(input.hasNextInt()) {
			numeroInt = input.nextInt();
			System.out.printf("È stato inserito un numero intero: %d.%n", numeroInt);
		} else {
			numeroDouble = input.nextDouble();
			System.out.printf("È stato inserito un numero double: %f.%n", numeroDouble);
		}

	}

}
