
public class EsempioTab {

	public static void main(String[] args) {
		
		int NMAX = 15;
		
		for(int i = 0; i < NMAX; i++) {
			System.out.printf("(%d):\t%d.%n", i, i);
		}

	}

}
