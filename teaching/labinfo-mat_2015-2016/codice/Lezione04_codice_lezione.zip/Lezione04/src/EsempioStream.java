
public class EsempioStream {

	public static void main(String[] args) {
		
		int n = 5;
		System.out.printf("Il numero inserito è %d.%n");

		
	}

}
