import java.util.Scanner;

public class LetturaIntero {

	public static void main(String[] args) {
		
		int num;
		Scanner input = new Scanner(System.in);

		System.out.print("Inserisci un numero intero: ");
		num = input.nextInt();
		input.close();

		System.out.printf("Il numero inserito è %d.%n", num);
	}

}
