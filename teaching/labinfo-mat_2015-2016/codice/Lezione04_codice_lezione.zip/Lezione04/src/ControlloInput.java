import java.util.Scanner;

public class ControlloInput {

	public static void main(String[] args) {

		int altezza;
		String nome;

		Scanner input = new Scanner(System.in);

		System.out.print("Inserisci la tua altezza (in cm): ");
		while (!input.hasNextInt()) {
			System.out.println("Il numero inserito non è un intero valido.");
			System.out.print("Inserisci la tua altezza (in cm): ");
			input.next();
		}

		altezza = input.nextInt();

		/*
		 * La prossima istruzione serve per leggere il carattere 'newline'
		 * dato che dopo avere inserito il numero viene premuto invio.
		 * 
		 * Inserisci la tua altezza (in cm): 174[invio]
		 * 
		 */
		input.nextLine();

		System.out.printf("Inserisci il tuo nome: ");
		nome = input.nextLine();
		input.close();

		System.out.printf("%s è alto %d cm", nome, altezza);

	}
}
