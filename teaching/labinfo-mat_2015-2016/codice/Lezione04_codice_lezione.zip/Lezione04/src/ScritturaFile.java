import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ScritturaFile {

	public static void main(String[] args) throws IOException {

		String text = "TestoEsempio";

		File file = new File("esempio.txt");
		FileWriter fw = new FileWriter(file);
		BufferedWriter bw = new BufferedWriter(fw);

		bw.write(text);
		bw.flush();
		bw.close();

	}

}
